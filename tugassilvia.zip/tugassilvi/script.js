// class kemdaraan {
//     constructor(model,merek,harga){
//         this.model = model;
//         this.merek = merek;
//         this.harga = harga;

//     }
//     maju(){
//         return `mesin ${this.model} ${this.merek} berjalan maju`;
//     }

//     berhenti(){
//         return `mesin ${this.model} ${this.merek} berhenti`;
//     }
// }
// let nama = new kendaraan("suprs", "toyota", 2000000);
// let kelas = new kendaraan("cbr", "honda", 30000);
// let bus = new kendaraan("laluna", "toyota", 40000);
// let angkot = new kendaraan("TA","honda",50000);
  
// console.log(mobil);
// console.log(motor);
// console.log(bus);
// console.log(angkot);


class siswa{
    constructor(nama,kelas,absen){
        this.nama  = nama ;
        this.kelas = kelas;
        this.absen = absen;
    }
    datang() {
        return `berjalan ${this.kelas} ${this.nama} datang`;
    }
    pulang() {
        return `berjalan ${this.kelas} ${this.nama} pulang`;
    }
}
let mega = new siswa("mega candra vinata", "x pplg 2",15);
let evi = new siswa("evi nur laili","x pplg 2",8);
let silvi = new siswa("silvia nisa aulia","x pplg 2",30);
let zahra = new siswa("zahra wahyu ananta","x pplg 2",35);

console.log(mega.datang());
console.log(evi.pulang());
console.log(silvi);
console.log(zahra);